<?php

    // realiza o carregamento automático do módulo
    $loading = new nuclear\autoloader();

    $loading->loader(__DIR__,'.php','/home/scripts');
