<?php
    /*
     * Framework Orbe - TRR
     * author Douglas Gonçalves de Souza
     * home - version 1.0000.0000.0000 - 2016-08-05
     * 
     * Licença Creative Commons
     * Orbe Framework de Douglas Gonçalves de Souza está licenciado com uma Licença
     * Creative Commons - Atribuição-NãoComercial-CompartilhaIgual 4.0 Internacional.
     * Baseado no trabalho disponível em https://bitbucket.org/douggonsouza/terra_nova.
     * Podem estar disponíveis autorizações adicionais às concedidas no âmbito desta
     * licença em https://bitbucket.org/douggonsouza/terra_nova.
     */

namespace root\home\controllers\home;

use vendor\douggs\nuclear\system\control\controller;

class index extends controller
{

	public $layout    = null;
	public $template  = null;
	public $variables = array();
    public $access    = null;

    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Responde a ação default
     * @param unknown $um
     * @param unknown $tres
     */
    public function index()
    {
        $variables = array('aplicativo' => 'Desenho e criação de aplicativos para desktop com a moderna linguagem de programação C#.');
        parent::view('index',$variables);
	}

}
        
