<?php

namespace controllers\home;

use nuclear\system\control\controller;

class index extends controller
{

    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Responde a ação default
     * @param unknown $um
     * @param unknown $tres
     */
    public function index()
    {
        $variables = array('aplicativo' => 'Desenho e criação de aplicativos para desktop com a moderna linguagem de programação C#.');
        parent::view('index',$variables);
	}

}
        
