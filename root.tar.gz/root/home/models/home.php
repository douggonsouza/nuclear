<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace models;

use vendor\douggs\nuclear\system\model\orm;

class home extends orm
{
    
    public function cadastra_cliente($request){
        
        $atual = date("Y-m-d H:i:s"); // data atual
        if(isset($request) && count($request) > 0){
            
            // iniciar entidades
            $contrato = parent::entity();
            $acesso   = parent::entity();
            $usuario  = parent::entity();
            // carregar entidades usuario
            $usuario->setTable('user')
                    ->setPk('user_id')
                    ->setFields('user_active',1,_INTEGER)
                    ->setFields('user_email',$request['email'],_STRING)
                    ->setFields('user_cpfcnpj',$request['cpfcnpj'],_STRING)
                    ->setFields('user_date',$atual,_DATE)
                    ->setFields('user_update',$atual,_DATE)
                    ->setFields('user_name',$request['nome'],_STRING);
            // inicia transação no banco
            parent::beginTransaction(); 
            // incluir usuário
            $usr = parent::insert($usuario);                        
            // existe inclusão
            if(isset($usr) && $usr > 0){

                // carregar acesso
                $acesso ->setTable('access')
                        ->setPk('acce_id')
                        ->setFields('acce_clas_id',$request['classe'],_INTEGER)
                        ->setFields('acce_active',1,_INTEGER)
                        ->setFields('acce_date',$atual,_DATE)
                        ->setFields('acce_update',$atual,_DATE)
                        ->setFields('acce_senha',md5($request['senha']),_STRING)
                        ->setFields('acce_user_id',$usr,_INTEGER);
                // novo acesso
                $acs = parent::insert($acesso);
                // criado acesso
                if(isset($acs) && $acs > 0){

                    // carregar entidade contrato
                    $contrato   ->setTable('contract')
                                ->setPk('cont_id')
                                ->setFields('cont_cons_id',$request['contracts'],_INTEGER)
                                ->setFields('cont_active',1,_INTEGER)
                                ->setFields('cont_date',$atual,_DATE)
                                ->setFields('cont_update',$atual,_DATE)
                                ->setFields('cont_acce_id',$acs,_INTEGER)
                                ->setFields('cont_safety',date("Y-m-d H:i:s",strtotime("+1 year")),_DATE);
                    // novo contrato
                    $ctt = parent::insert($contrato);
                    //incluido contrato
                    if(isset($ctt) && $ctt > 0){

                        // disparar alerta
                        parent::commitTransaction();
                        return true;
                    }
                    else
                        parent::rollbackTransaction();
                }
                else
                    parent::rollbackTransaction();
            }
            else
                parent::rollbackTransaction();
        }
        return false;
    }
    
}

