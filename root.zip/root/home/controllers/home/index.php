<?php

namespace root\home\controllers\home;

use Nuclear\alerts\alerts;
use Nuclear\system\control\action;

class index extends action
{
    const MAIL_TO = 'afluxoco@afluxo.com.br';

    public function __construct()
    {
        parent::setLayout('breve.phtml');
    }

    /**
     * Responde a ação default
     * @param unknown $um
     * @param unknown $tres
     */
    public function main(...$param)
    {
        $variables = array('aplicativo' => 'Desenho e criação de aplicativos para desktop com a moderna linguagem de programação C#.');

        if(array_key_exists("cmVjZWJlciBtZW5zYWdlbnMgZGEgZW1wcmVzYQ==",$_POST)){
            $to      = self::MAIL_TO;
            $subject = 'Inscrição';
            $message =$_POST['email'];
            $headers = 'From: '.$_POST['email'] . "\r\n";

            $result = mail($to, $subject, $message, $headers);
        }

        if(array_key_exists("Y29udGF0byBjb20gYSBBZmx1eG8=",$_POST)){
            $to      = self::MAIL_TO;
            $subject = $_POST['subject'];
            $message = $_POST['message'];
            $headers = 'From: '.$_POST['email'] . "\r\n";

            $result = mail($to, $subject, $message, $headers);
        }
        parent::view(null, $variables);
	}
}
        
