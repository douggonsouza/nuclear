<?php

namespace root\home\controllers\home;

use Nuclear\system\control\action;

class index extends action
{

    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Responde a ação default
     * @param unknown $um
     * @param unknown $tres
     */
    public function main(...$param)
    {
        $variables = array('aplicativo' => 'Desenho e criação de aplicativos para desktop com a moderna linguagem de programação C#.');
        parent::view(null, $variables);
	}

}
        
